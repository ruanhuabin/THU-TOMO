/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-avx2-128.h"
#include "../common/n2sv_64.c"
